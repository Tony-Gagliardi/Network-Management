import math 

def hypotenuse(legA, legB):
	hyp = math.sqrt((legA*legA) + (legB*legB))
	print 'Hypotenuse is ' + str(hyp)
